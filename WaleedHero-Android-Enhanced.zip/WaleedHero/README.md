# Waleed Hero - Godot Prototype

An original superhero action-game prototype for Godot 4.x. The hero has an original blue/red/gold outfit concept and a gold W chest emblem. The project is not affiliated with Superman or DC.

## Included gameplay
- Procedurally generated low-poly city with roads and lit windows
- Third-person follow camera
- Touch buttons for movement, flight, punch, special energy attack, and rescue
- Enemy pursuit and close-range damage
- Three rescue targets and four enemy encounters
- Health, coins, XP, level progression, and local save data
- Arabic HUD and mission progress

## Open
1. Extract the ZIP.
2. In Godot 4.x choose **Import**.
3. Select `project.godot` from this folder.
4. Press Play.

## Android export
This is a Godot source project, not an APK. Install Godot 4.x and Android export templates, configure an Android SDK/JDK, then use Project > Export > Android. Set the project to landscape. Test on a real phone before publishing.

## Current prototype limitations
- Placeholder geometric character and enemies; final custom 3D models/animations are not included.
- No online multiplayer, voice acting, store billing, or cloud saves.
- Mission and combat systems are starter gameplay systems and need balancing/testing.
