extends Node3D

# Waleed Hero - mobile-friendly playable prototype (Godot 4.x)
var hero: CharacterBody3D
var camera: Camera3D
var hud: CanvasLayer
var info_label: Label
var health_label: Label
var mission_label: Label
var coins_label: Label
var move_dir := Vector2.ZERO
var flying := false
var attacking := false
var special_ready := true
var health := 100.0
var coins := 0
var xp := 0
var level := 1
var rescued := 0
var enemies_defeated := 0
var speed := 8.0
var fly_speed := 14.0
var gravity := 22.0
var enemy_nodes: Array[Node3D] = []
var civilian_nodes: Array[Node3D] = []
var save_path := "user://waleed_hero_save.cfg"
var mission_stage := 0
var world_time := 0.0

func _ready() -> void:
    _load_progress()
    _make_world()
    _make_hero()
    _make_camera()
    _make_people()
    _make_hud()
    _update_hud()

func _box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    m.mesh = mesh
    m.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.78
    m.material_override = mat
    parent.add_child(m)
    return m

func _make_world() -> void:
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    sky.sky_material = ProceduralSkyMaterial.new()
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.82, 1.0)
    env.ambient_light_energy = 0.85
    env_node.environment = env
    add_child(env_node)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -30, 0)
    sun.light_energy = 1.25
    add_child(sun)

    var ground := StaticBody3D.new()
    ground.name = "CityGround"
    _box(ground, Vector3(0, -0.5, 0), Vector3(220, 1, 220), Color(0.20, 0.43, 0.25))
    var ground_shape := CollisionShape3D.new()
    var plane := BoxShape3D.new()
    plane.size = Vector3(220, 1, 220)
    ground_shape.shape = plane
    ground_shape.position.y = -0.5
    ground.add_child(ground_shape)
    add_child(ground)

    for i in range(-5, 6):
        _box(self, Vector3(i * 18, 0.015, 0), Vector3(7, 0.04, 220), Color(0.12, 0.13, 0.16))
        _box(self, Vector3(0, 0.02, i * 18), Vector3(220, 0.04, 7), Color(0.12, 0.13, 0.16))
        for side in [-1, 1]:
            _box(self, Vector3(i * 18 + side * 4.0, 0.045, 0), Vector3(0.12, 0.03, 220), Color(0.95, 0.78, 0.18))
            _box(self, Vector3(0, 0.05, i * 18 + side * 4.0), Vector3(220, 0.03, 0.12), Color(0.95, 0.78, 0.18))

    var rng := RandomNumberGenerator.new()
    rng.seed = 81
    for x in range(-5, 6):
        for z in range(-5, 6):
            if abs(x) < 2 and abs(z) < 2:
                continue
            var h := rng.randf_range(7.0, 27.0)
            var w := rng.randf_range(6.0, 10.0)
            var col := Color(rng.randf_range(0.24, 0.48), rng.randf_range(0.30, 0.55), rng.randf_range(0.42, 0.68))
            var building := _box(self, Vector3(x * 18, h / 2.0, z * 18), Vector3(w, h, w), col)
            building.name = "CityBuilding"
            for floor_i in range(1, int(h / 3.0)):
                _box(self, Vector3(x * 18, floor_i * 3.0, z * 18 + w / 2.0 + 0.06), Vector3(w * 0.62, 0.55, 0.08), Color(0.55, 0.82, 1.0))

    # Mission landmark: glowing rescue tower
    _box(self, Vector3(28, 8, -28), Vector3(9, 16, 9), Color(0.42, 0.20, 0.18))
    _box(self, Vector3(28, 16.2, -28), Vector3(3, 0.3, 3), Color(1.0, 0.25, 0.06))

func _make_hero() -> void:
    hero = CharacterBody3D.new()
    hero.name = "WaleedHero"
    hero.position = Vector3(0, 0.1, 0)
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.48
    shape.height = 2.2
    collision.shape = shape
    collision.position.y = 1.1
    hero.add_child(collision)

    var body := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 2.2
    body.mesh = capsule
    body.position.y = 1.1
    var blue := StandardMaterial3D.new()
    blue.albedo_color = Color(0.035, 0.10, 0.48)
    body.material_override = blue
    hero.add_child(body)
    _box(hero, Vector3(0, 1.48, -0.49), Vector3(0.64, 0.42, 0.10), Color(1.0, 0.72, 0.05))
    _box(hero, Vector3(0, 1.13, 0.48), Vector3(1.18, 1.65, 0.10), Color(0.78, 0.025, 0.07))
    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.36
    head_mesh.height = 0.72
    head.mesh = head_mesh
    head.position.y = 2.42
    var skin := StandardMaterial3D.new()
    skin.albedo_color = Color(0.82, 0.57, 0.39)
    head.material_override = skin
    hero.add_child(head)
    add_child(hero)

func _make_camera() -> void:
    camera = Camera3D.new()
    camera.position = Vector3(0, 5, 9)
    camera.current = true
    add_child(camera)

func _make_people() -> void:
    _spawn_civilian(Vector3(24, 0, -24))
    _spawn_civilian(Vector3(-27, 0, 18))
    _spawn_civilian(Vector3(42, 0, 30))
    _spawn_enemy(Vector3(15, 0, 10))
    _spawn_enemy(Vector3(-18, 0, -14))
    _spawn_enemy(Vector3(36, 0, -8))
    _spawn_enemy(Vector3(-38, 0, 35))

func _spawn_civilian(pos: Vector3) -> void:
    var person := Node3D.new()
    person.position = pos
    var mesh := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.32
    capsule.height = 1.55
    mesh.mesh = capsule
    mesh.position.y = 0.78
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.15, 0.9, 0.55)
    mesh.material_override = mat
    person.add_child(mesh)
    add_child(person)
    civilian_nodes.append(person)

func _spawn_enemy(pos: Vector3) -> void:
    var enemy := Node3D.new()
    enemy.position = pos
    enemy.set_meta("hp", 3)
    enemy.set_meta("hit_timer", 0.0)
    var mesh := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.9
    mesh.mesh = capsule
    mesh.position.y = 0.95
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.20, 0.055, 0.075)
    mesh.material_override = mat
    enemy.add_child(mesh)
    _box(enemy, Vector3(0, 1.45, -0.43), Vector3(0.5, 0.24, 0.08), Color(1.0, 0.08, 0.05))
    add_child(enemy)
    enemy_nodes.append(enemy)

func _make_hud() -> void:
    hud = CanvasLayer.new()
    add_child(hud)
    var panel := PanelContainer.new()
    panel.position = Vector2(14, 12)
    panel.size = Vector2(440, 142)
    hud.add_child(panel)
    var stack := VBoxContainer.new()
    panel.add_child(stack)
    var title := Label.new()
    title.text = "WALEED HERO  •  بطل المدينة"
    title.add_theme_font_size_override("font_size", 23)
    stack.add_child(title)
    health_label = Label.new()
    stack.add_child(health_label)
    coins_label = Label.new()
    stack.add_child(coins_label)
    info_label = Label.new()
    info_label.text = "الحالة: على الأرض"
    stack.add_child(info_label)
    mission_label = Label.new()
    mission_label.add_theme_color_override("font_color", Color(1.0, 0.82, 0.2))
    stack.add_child(mission_label)

    var vp := get_viewport().get_visible_rect().size
    _button("▲", Vector2(94, vp.y - 190), Vector2(76, 62), func(): move_dir.y = -1, func(): move_dir.y = 0)
    _button("▼", Vector2(94, vp.y - 55), Vector2(76, 48), func(): move_dir.y = 1, func(): move_dir.y = 0)
    _button("◀", Vector2(12, vp.y - 120), Vector2(76, 62), func(): move_dir.x = -1, func(): move_dir.x = 0)
    _button("▶", Vector2(176, vp.y - 120), Vector2(76, 62), func(): move_dir.x = 1, func(): move_dir.x = 0)
    _button("طيران", Vector2(vp.x - 180, vp.y - 205), Vector2(160, 58), func(): _toggle_flight(), func(): pass)
    _button("لكمة", Vector2(vp.x - 180, vp.y - 137), Vector2(160, 58), func(): _attack(), func(): pass)
    _button("قوة خاصة", Vector2(vp.x - 180, vp.y - 69), Vector2(160, 58), func(): _special_attack(), func(): pass)
    _button("إنقاذ", Vector2(vp.x - 350, vp.y - 69), Vector2(150, 58), func(): _rescue_nearby(), func(): pass)

func _button(txt: String, pos: Vector2, sz: Vector2, down: Callable, up: Callable) -> void:
    var b := Button.new()
    b.text = txt
    b.position = pos
    b.size = sz
    b.add_theme_font_size_override("font_size", 20)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_stylebox_override("normal", _button_style(Color(0.025, 0.12, 0.30, 0.88)))
    b.add_theme_stylebox_override("pressed", _button_style(Color(0.04, 0.42, 0.78, 0.95)))
    hud.add_child(b)
    b.button_down.connect(down)
    b.button_up.connect(up)

func _button_style(c: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = c
    s.corner_radius_top_left = 18
    s.corner_radius_top_right = 18
    s.corner_radius_bottom_left = 18
    s.corner_radius_bottom_right = 18
    s.border_width_left = 2
    s.border_width_right = 2
    s.border_width_top = 2
    s.border_width_bottom = 2
    s.border_color = Color(0.20, 0.72, 1.0)
    return s

func _toggle_flight() -> void:
    flying = not flying
    info_label.text = "الحالة: " + ("تحليق في السماء" if flying else "على الأرض")

func _attack() -> void:
    if attacking:
        return
    attacking = true
    var hit_count := 0
    for enemy in enemy_nodes.duplicate():
        if is_instance_valid(enemy) and hero.global_position.distance_to(enemy.global_position) < 4.5:
            _damage_enemy(enemy, 1)
            hit_count += 1
    info_label.text = "ضربة قوية!" if hit_count > 0 else "اقترب من العدو للهجوم"
    await get_tree().create_timer(0.35).timeout
    attacking = false

func _special_attack() -> void:
    if not special_ready:
        info_label.text = "القدرة الخاصة قيد الشحن"
        return
    special_ready = false
    var hit := 0
    for enemy in enemy_nodes.duplicate():
        if is_instance_valid(enemy) and hero.global_position.distance_to(enemy.global_position) < 13.0:
            _damage_enemy(enemy, 3)
            hit += 1
    info_label.text = "انفجار الطاقة! أصبت %d عدو" % hit
    await get_tree().create_timer(7.0).timeout
    special_ready = true

func _damage_enemy(enemy: Node3D, amount: int) -> void:
    var hp: int = int(enemy.get_meta("hp")) - amount
    enemy.set_meta("hp", hp)
    if hp <= 0:
        enemy_nodes.erase(enemy)
        enemy.queue_free()
        enemies_defeated += 1
        coins += 25
        xp += 20
        _check_level()
        _update_hud()

func _rescue_nearby() -> void:
    for person in civilian_nodes.duplicate():
        if is_instance_valid(person) and hero.global_position.distance_to(person.global_position) < 5.0:
            civilian_nodes.erase(person)
            person.queue_free()
            rescued += 1
            coins += 50
            xp += 30
            info_label.text = "تم إنقاذ مدني بنجاح! +50 عملة"
            _check_level()
            _update_hud()
            return
    info_label.text = "اقترب من شخص باللون الأخضر لإنقاذه"

func _check_level() -> void:
    while xp >= level * 100:
        xp -= level * 100
        level += 1
        health = 100.0
        info_label.text = "مبروك! وصلت للمستوى %d" % level
    _save_progress()

func _update_hud() -> void:
    health_label.text = "❤️ الصحة: %d%%   ⭐ المستوى: %d  (خبرة %d)" % [int(health), level, xp]
    coins_label.text = "🪙 العملات: %d   🦹 الأعداء: %d   🧍 الإنقاذ: %d" % [coins, enemies_defeated, rescued]
    if rescued < 3:
        mission_label.text = "المهمة: أنقذ 3 مدنيين (%d/3)" % rescued
    elif enemies_defeated < 4:
        mission_label.text = "المهمة: اهزم 4 أعداء (%d/4)" % enemies_defeated
    else:
        mission_label.text = "اكتملت المهمة! أنت حامي المدينة 🏆"

func _physics_process(delta: float) -> void:
    if not is_instance_valid(hero):
        return
    world_time += delta
    var input := move_dir
    if Input.is_action_pressed("ui_up"):
        input.y = -1
    if Input.is_action_pressed("ui_down"):
        input.y = 1
    if Input.is_action_pressed("ui_left"):
        input.x = -1
    if Input.is_action_pressed("ui_right"):
        input.x = 1
    var forward := -camera.global_transform.basis.z
    forward.y = 0
    forward = forward.normalized()
    var right := camera.global_transform.basis.x
    right.y = 0
    right = right.normalized()
    var direction := (right * input.x + forward * -input.y).normalized()
    var current_speed := fly_speed if flying else speed
    hero.velocity.x = direction.x * current_speed
    hero.velocity.z = direction.z * current_speed
    if flying:
        hero.velocity.y = 4.0
        if Input.is_action_pressed("ui_accept"):
            hero.velocity.y = 9.0
    else:
        if not hero.is_on_floor():
            hero.velocity.y -= gravity * delta
        else:
            hero.velocity.y = -0.5
    hero.move_and_slide()
    if direction.length() > 0.1:
        hero.rotation.y = atan2(-direction.x, -direction.z)
    camera.global_position = camera.global_position.lerp(hero.global_position + Vector3(0, 4.5, 9), delta * 4.0)
    camera.look_at(hero.global_position + Vector3(0, 1.25, 0), Vector3.UP)
    _update_enemies(delta)
    _check_world_bounds()

func _update_enemies(delta: float) -> void:
    for enemy in enemy_nodes:
        if not is_instance_valid(enemy):
            continue
        var to_hero := hero.global_position - enemy.global_position
        to_hero.y = 0
        if to_hero.length() > 2.2:
            enemy.global_position += to_hero.normalized() * delta * 2.0
        else:
            var timer: float = float(enemy.get_meta("hit_timer")) - delta
            if timer <= 0.0:
                health = maxf(0.0, health - 5.0)
                timer = 1.2
                _update_hud()
                if health <= 0.0:
                    _respawn_hero()
            enemy.set_meta("hit_timer", timer)

func _check_world_bounds() -> void:
    if abs(hero.global_position.x) > 105 or abs(hero.global_position.z) > 105 or hero.global_position.y < -15:
        hero.global_position = Vector3.ZERO
        hero.velocity = Vector3.ZERO
        flying = false

func _respawn_hero() -> void:
    health = 100.0
    hero.global_position = Vector3.ZERO
    hero.velocity = Vector3.ZERO
    flying = false
    info_label.text = "تم إنقاذك وإعادتك إلى مركز المدينة"
    _update_hud()

func _load_progress() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(save_path) == OK:
        coins = int(cfg.get_value("progress", "coins", 0))
        xp = int(cfg.get_value("progress", "xp", 0))
        level = int(cfg.get_value("progress", "level", 1))
        enemies_defeated = int(cfg.get_value("progress", "enemies_defeated", 0))
        rescued = int(cfg.get_value("progress", "rescued", 0))

func _save_progress() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("progress", "coins", coins)
    cfg.set_value("progress", "xp", xp)
    cfg.set_value("progress", "level", level)
    cfg.set_value("progress", "enemies_defeated", enemies_defeated)
    cfg.set_value("progress", "rescued", rescued)
    cfg.save(save_path)

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        _save_progress()
